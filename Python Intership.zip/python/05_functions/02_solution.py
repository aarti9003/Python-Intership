def add(numOne, numTwo):
    return numOne + numTwo


print(add(5, 5))
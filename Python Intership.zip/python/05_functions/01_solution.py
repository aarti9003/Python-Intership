def square(number):
    return number ** 2


result = square(4)
print(16)

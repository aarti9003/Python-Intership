def greet(name = "User"):
    return "Hello, " + name + " !"


print(greet("chai"))
print(greet())
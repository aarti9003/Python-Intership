


cube = lambda x: x ** 3

print(cube(3))